from flask import render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from .forms import LoginForm, RegisterForm, PurchaseItemForm, SellItemForm, RegistrationForm
from .models import User, Item
from . import app, db

@app.route('/')
@app.route('/profile')
@login_required
def profile():
    """Profile page"""
    return render_template('profile.html', title='Profile')

@app.route("/market", methods=['GET', 'POST'])
@login_required
def market_page():
    """Market page with buy and sell functionality"""
    purchase_form = PurchaseItemForm()
    sell_form = SellItemForm()
    if request.method == "POST":
        if 'purchase' in request.form and purchase_form.validate_on_submit():
            item_obj = Item.query.filter_by(name=request.form.get('purchased_item')).first()
            if item_obj and current_user.can_purchase(item_obj):
                item_obj.buy(current_user)
                flash(f"Congratulations! You purchased {item_obj.name} for {item_obj.price}$", category='success')
            else:
                flash("Unfortunately, you don't have enough money to purchase this item!", category='danger')

        elif 'sell' in request.form and sell_form.validate_on_submit():
            item_obj = Item.query.filter_by(name=request.form.get('sold_item')).first()
            if item_obj and current_user.can_sell(item_obj):
                item_obj.sell(current_user)
                flash(f"Congratulations! You sold {item_obj.name} back to market!", category='success')
            else:
                flash("Something went wrong with selling this item!", category='danger')

        return redirect(url_for('market_page'))

    items = Item.query.filter_by(owner=None).all()
    owned_items = Item.query.filter_by(owner=current_user.id).all()
    return render_template('MARKET.html', title='Market', items=items, owned_items=owned_items, purchase_form=purchase_form, sell_form=sell_form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login URL"""
    if current_user.is_authenticated:
        return redirect(url_for('profile'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            flash('Welcome back!')
            next_page = request.args.get('next')
            return redirect(next_page if next_page else url_for('profile'))
        flash('Invalid username or password')

    return render_template('LOGIN.html', title='Login', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Registration URL"""
    if current_user.is_authenticated:
        return redirect(url_for('profile'))

    form = RegisterForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email_address=form.email_address.data)
        user.password = form.password1.data
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash('Account created successfully! You are now logged in.')
        return redirect(url_for('profile'))

    return render_template('REGISTER.html', title='Register', form=form)

@app.route('/logout')
def logout():
    """Used to log out a user"""
    logout_user()
    flash("You have been logged out!", category='info')
    return redirect(url_for('login'))

@app.route("/admin")
@login_required
def admin_page():
    """Admin panel access"""
    if not current_user.is_admin:
        flash('Access denied: Admins only.', category='danger')
        return redirect(url_for('profile'))
    users = User.query.all()
    items = Item.query.all()
    return render_template('ADMIN.html', title='Admin', users=users, items=items)
